<footer>
    <p>&copy; <?php echo date("Y"); ?> My Website</p>
</footer>
