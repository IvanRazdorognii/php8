<?php
$comments = file_get_contents('data/comments.txt');
if (!empty($comments)) {
    echo nl2br($comments);
} else {
    echo "No comments yet.";
}
?>
