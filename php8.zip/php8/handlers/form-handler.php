<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'] ?? '';
    $comment = $_POST['comment'] ?? '';

    if (!empty($name) && !empty($comment)) {
        $data = "$name: $comment\n";
        file_put_contents('data/comments.txt', $data, FILE_APPEND | LOCK_EX);
    }
}

// Перенаправляем пользователя на главную страницу после того, как данные будут записаны
header('Location: /index.php');
exit;
?>
